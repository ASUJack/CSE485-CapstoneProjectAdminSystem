package dev.capstone.asu.Capstone.Project.Admin.System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CapstoneProjectAdminSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
