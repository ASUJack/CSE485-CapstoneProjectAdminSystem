package dev.capstone.asu.Capstone.Project.Admin.System.Students;

import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepo extends JpaRepository<Student, Long> {



}
