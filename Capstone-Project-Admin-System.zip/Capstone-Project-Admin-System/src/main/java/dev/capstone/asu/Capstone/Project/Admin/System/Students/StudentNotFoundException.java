package dev.capstone.asu.Capstone.Project.Admin.System.Students;

public class StudentNotFoundException extends RuntimeException {
    public StudentNotFoundException(String message) {
        super(message);
    }
}
