package dev.capstone.asu.Capstone.Project.Admin.System.Projects;

public class ProjectNotFoundException extends RuntimeException {

    public ProjectNotFoundException(String message) {
        super(message);
    }
}
