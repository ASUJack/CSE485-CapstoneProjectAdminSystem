package dev.capstone.asu.Capstone.Project.Admin.System.Projects;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ProjectRepo extends JpaRepository<Project, Long>{
}
